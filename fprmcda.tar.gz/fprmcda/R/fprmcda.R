#' fprmcda:  A package for Visualising Small and Medium Scale Fisheries Footprints using Multi-Criteria
#' Decision Analysis.
#'
#' \bold{fprmcda} package integrates the most influential components and criteria affecting Small and Medium-Scale
#' Fisheries (bathymetry, distance from coast, Chl-a concentration, fishing effort, vessel capacity of ports,
#' marine traffic activity, etc.) to define fishing
#' footprint intensity. This tool combines Multi-Criteria Decision Analysis methods and geospatial
#' techniques to estimate a spatial fishing pressure index. Package
#' development was based on Kavadas et al. (2015).
#' \itemize{
#' \item The main functions of the package are:
#' \tabular{lll}{ \code{\link{fgrade}} \tab add scores to a dataset\cr
#' \code{\link{ahp_optim}} \tab performs the Analytic Hierarchy Process\cr
#' \code{\link{idwfg}} \tab performs an inverse distance weighting
#' interpolation to a fishing dataset\cr \code{\link{FuzzyMember}} \tab
#' normalizes a dataset to [0,1] \cr \code{\link{csv2raster}} \tab converts a
#' csv file to a RasterLayer object\cr \code{\link{shp2raster}} \tab converts a
#' shapefile to a RasterLayer object\cr }
#' \item To install dependencies of fprmcda, try in R \cr
#'install.packages(c("raster", "phylin","sp", "spatstat", "deldir", "maptools", "rgdal", "rasterVis", "RColorBrewer", "maps",
#'                     "mapdata", "FuzzyAHP", "tmap", "tmaptools"), dependencies = TRUE) \cr
#'or \cr
#'install.packages(c("raster", "phylin","sp", "spatstat", "deldir", "maptools", "rgdal", "rasterVis", "RColorBrewer", "maps",
#'                     "mapdata", "FuzzyAHP", "tmap", "tmaptools"), repos = "http://cran.us.r-project.org", dependencies = TRUE)\cr
#' \item See the package vignettes for examples of
#' use. To access the vignettes, you can either \cr
#' a) visit cran.r-project.org/web/packages/fprmcda and click on Getting
#' Started with fprmcda, or \cr
#' b) start R, type \code{library(fprmcda)} and then type\cr
#' \code{path <- system.file("doc", "fprmcdaTutorial.pdf", package = "fprmcda")}\cr
#' \code{system(paste0('open "', path, '"'))}
#' \item Type \code{demo(package = "fprmcda")} to see available demos of the
#' \bold{fprmcda}.\cr
#' \item Type \code{file.edit(system.file("demo", "demo1.R", package = "fprmcda"))} \cr
#' \item Type \code{file.edit(system.file("demo", "demo2.R", package = "fprmcda"))} \cr to access the source codes of the demos
#' and \cr
#' \item Run \code{demo("demo1", package = "fprmcda", ask = FALSE)} and \cr
#' \code{demo("demo2", package = "fprmcda", ask = FALSE)} \cr
#' to generate the plots of the demos 1 and 2.
#'}
#'
#' @author Dimitris V. Politikos, Irida Maina and Stefanos Kavvadas
#'
#' \emph{Maintainer}: Dimitris V. Politikos <dimpolit@@hcmr.gr>
#'
#' @references Kavadas, S., I. Maina, D. Damalas, I. Dokos, M. Pantazi, and V.
#' Vassilopoulou (2015). Multi-Criteria Decision Analysis as a tool to extract
#' fishing footprints and estimate fishing pressure: application to small scale
#' coastal fisheries and implications for management in the context of the
#' Maritime Spatial Planning Directive. Mediterranean Marine Science
#' 16:294-304.  \url{http://dx.doi.org/10.12681/mms.1087}\cr
#'
#' The \bold{fprmcda} package was built within the framework of
#' \href{https://www.msp-platform.eu/projects/portodimare-geoportal-tools-data-sustainable-management-coastal-and-marine}{Portodimare Project}.
#'
#' To cite the fprmcda package, use \code{citation("fprmcda")}.
#'
#' @docType package
#' @name fprmcda
NULL
