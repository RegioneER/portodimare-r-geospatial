#' Lengths of Major North American Rivers
#'
#' This data set gives
#'
#'
#' @name FishData
#' @docType data
#' @format A vector containing 141 observations.
#' @references McNeil, D. R. (1977) \emph{Interactive Data Analysis}.  New
#' York: Wiley.
#' @source World Almanac and Book of Facts, 1975, page 406.
#' @keywords datasets
NULL



