#' Grading of a dataset
#'
#' Grades a dataset based on scores.
#'
#' @importFrom stats stepfun
#'
#' @param object The data object to apply the criteria. Data can be vectors,
#' matrices, dataframes, shapefiles and rasters.
#' @param cuts Cuts of the data, on which we define the scores.
#' @param scores Integer scores based on cuts (values MUST be between 0 and 5).
#' @return Return of data object with values from 0 to 5.
#' @examples
#'
#'
#'   #------------ Example 1 -----------#
#'   library(fprmcda)
#'   object <- runif(100, -1000, 1000)
#'   # Assign cuts
#'   cuts <- c(-Inf, 0, 50, 100, 150, 200, 500)
#'   # Assign scores
#'   scores <- c(NA, 1, 2, 3, 4, 5, 0)
#'   object_scored = fgrade(object, cuts, scores)
#'   # Plot of object and scored object
#'   x11()
#'   par(mfrow=c(2,1))
#'   hist(object)
#'   barplot(table(object_scored), main = "Scored object")
#'
#'   #------------ Example 2 -----------#
#'   library(fprmcda)
#'   library(raster)
#'   # Generate a raster r
#'   r <- raster(ncol=5, nrow=5)
#'   values(r) <- rnorm(25, 10, 10)
#'   # Assign cuts and scores
#'   cuts <- c(-Inf, 0, 5, 10, 15, 20)
#'   scores <- c(1, 2, 3, 4, 5, 0)
#'   # Create the scored raster: r_scored
#'   r_scored = r
#'   # Update r_scored based on cuts and scores
#'   values(r_scored) = fgrade(values(r_scored), cuts, scores)
#'   # Make the plots of r and r_scored rasters
#'   x11()
#'   par(mfrow=c(2,1))
#'   plot(r, main = "Unscored")
#'   plot(r_scored, main = "Scored")
#'
#' @export
fgrade <- function(object, cuts, scores) {
    fstep <- stepfun(cuts[-1], scores)
    f = fstep(object)
    if (max(scores, na.rm = T) > 5)
        stop("scores must be <5")
    if (length(which(scores < 0)) > 0)
        stop("scores must be positive")
    return(f)
}

#### Apply Analytic Hierarchy Process (AHP) ####


#' Analytic Hierarchy Process
#'
#' Compute the weights of analytic hierarchy process by adjusting the pair-wise
#' comparison matrix through an interative scheme till consistency ratio
#' criterion is achieved (C.R. <0.1).
#'
#' @importFrom FuzzyAHP pairwiseComparisonMatrix consistencyRatio calculateWeights
#'
#' @param pairwise_matrix The nxn pair-wise comparison matrix.
#' @param lambda A weighting factor in (0,1). Default value is 0.5. The higher
#' the lambda value the higher the adjustement to the pair-wise comparison
#' matrix.
#' @return \item{weights}{ Weights to measure the importance of each component (1,2,...,n).
#' } \item{cr}{ The consistency ratio. }
#'
#' \item{pairwise_matrix_adj}{ The adjusted pairwise matrix with acceptable
#' consistency (C.R. < 0.1).  }
#'
#' \item{delta}{ Measure the maximum absolute difference of elements between
#' the pairwise matrix and adjusted pairwise matrix. It should be <2.  }
#'
#' \item{sig}{ A metric that measures the standard deviation of the difference
#' of elements between the pairwise matrix and adjusted pairwise matrix. It
#' should be ~1.  }
#' @references Kavadas, S., I. Maina, D. Damalas, I. Dokos, M. Pantazi, and V.
#' Vassilopoulou (2015). Multi-Criteria Decision Analysis as a tool to extract
#' fishing footprints and estimate fishing pressure: application to small scale
#' coastal fisheries and implications for management in the context of the
#' Maritime Spatial Planning Directive. Mediterranean Marine Science
#' 16:294-304. \url{http://dx.doi.org/10.12681/mms.1087}
#'
#' Saaty, T.L. (2001). Decision Making for Leaders: The Analytic Hierarchy
#' Process for Decisions in a Complex World, New Edition 2001 (3 Revised).
#' Pittsburgh, PA: RWS Publications, ISBN 978-0962031786.
#'
#' Xu, Z. (2004). A practical method for improving consistency of judgement
#' matrix in the ahp. Journal of Systems Science and Complexity, 17(2).
#' @examples
#'
#' library(FuzzyAHP)
#' library(fprmcda)
#' matrix_values <- c(1,3,4,5,7,
#'                   1/3,1,2,2,4,
#'                   1/4,1/2,1,2,3,
#'                   1/5,1/2,1/2,1,3,
#'                   1/7,1/4,1/3,1/3,1)
#' matrix_values = matrix(matrix_values,nrow = 5,ncol = 5, byrow = TRUE)
#' ahp_outputs = ahp_optim(matrix_values)
#' ahp_outputs
#' @export
ahp_optim <- function(pairwise_matrix, lambda = 0.5) {
    RI <- c(0, 0, 0.52, 0.89, 1.12, 1.26, 1.36, 1.41, 1.46, 1.49, 1.52, 1.54, 1.56, 1.58,
        1.59)
    PairwiseMatInit = pairwise_matrix

    if (nrow(pairwise_matrix) != ncol(pairwise_matrix))
        stop("Pairwise matrix must be square")

    # Calculate largest eigevalue and principal eigenvector
    e <- eigen(pairwise_matrix)
    lmax = max(Re(e$values[abs(Im(e$values)) < 1e-06]))
    w <- Re(e$vectors[, 1])/sum(Re(e$vectors[, 1]))

    # Calculate consistency ratio of PairwiseMatInit
    PairwiseMatInit = pairwiseComparisonMatrix(PairwiseMatInit)
    CR = consistencyRatio(PairwiseMatInit, print.report = FALSE)
    PairwiseMatInit = PairwiseMatInit@values
    k = 0

    # while loop till the consistency ratio (<0.1) is achieved
    while (CR > 0.1) {
        wmat <- diag(1, length(w))
        for (i in 1:length(w)) {
            for (j in 1:length(w)) {
                wmat[i, j] = w[j]/w[i]
            }
        }

        PairwiseMat_wmat = pairwise_matrix * wmat
        id = which(PairwiseMat_wmat == max(PairwiseMat_wmat), arr.ind = TRUE)
        pairwise_matrix[id[1], id[2]] <- lambda * pairwise_matrix[id[1], id[2]] + (1 - lambda) *
            (w[id[1]]/w[id[2]])
        pairwise_matrix[id[2], id[1]] <- 1/pairwise_matrix[id[1], id[2]]

        e <- eigen(pairwise_matrix)
        lmax = max(Re(e$values[abs(Im(e$values)) < 1e-06]))
        w <- Re(e$vectors[, 1])/sum(Re(e$vectors[, 1]))
        CI = (lmax - nrow(pairwise_matrix))/(nrow(pairwise_matrix) - 1)
        CR = CI/RI[nrow(pairwise_matrix)]

        k = k + 1

        if (k > 200) stop("Iterations > 200, adjust pairwise_matrix")

    }

    # Calculate weights, consistency ratio and diagnostics of AHP
    delta = max(abs(pairwise_matrix - PairwiseMatInit))
    sig = sqrt(sum((pairwise_matrix - PairwiseMatInit)^2))/nrow(pairwise_matrix)
    pairwise_matrix = pairwiseComparisonMatrix(pairwise_matrix)
    weights = calculateWeights(pairwise_matrix)
    CR = consistencyRatio(pairwise_matrix, print.report = FALSE)

    if (delta > 2)
        warning("delta is > 2")
    if (sig > 1.5)
        warning("sig is > 1.5")

    return(list("weights" = weights@weights, "cr" = CR, "matrix_adj" = pairwise_matrix@values,
        delta = delta, sig = sig))
}

### apply IDW interpolation to Fishing vessel activity data ###


#' Fishing gear interpolation
#'
#' Interpolate Fishing Gear data using Inverse Distance Weighting algorithm.
#' @importFrom phylin idw
#' @importFrom raster xFromCol yFromRow rasterize projection
#' @importFrom sp proj4string
#'
#' @param dataframe A dataframe of points to be interpolated. Dataframe must
#' contain x and y locations, and a column of values to be interpolated.
#' @param rmask A reference raster object, used to create a grid for the dataframe.
#' @param method Method to calculate weights for Inverse distance idw. Should
#' be "Shepard" (default), "Modified" or "Neighbours". For more details, see
#' \href{https://cran.r-project.org/web/packages/phylin/index.html}{Phylin package}.
#' @param p The power to use in weight calculation. If missing, it takes the
#' value 2.
#' @param R Radius to use with Modified Shepard method. If missing, it takes
#' the value R=2.
#' @param N Maximum number of neighbours to use with Shepard with neighbours.
#' If Missing, it takes the value N=15.
#' @return \item{raster}{ Returns a RasterLayer object with interpolated
#' values.}\item{rmse}{ Error using leave-one-out cross validation. For more
#' details about the validation, see
#' \href{https://www.cs.cmu.edu/~schneide/tut5/node42.html}{Cross validation}.}
#' @examples
#'
#'  library(phylin)
#'  library(raster)
#'  library(rasterVis)
#'  library(maps)
#'  library(mapdata)
#'  library(maptools)
#'  library(fprmcda)
#'
#'  # Data points represent x,y locations and fishing gear
#'  data <- data.frame(c(runif(15,24.3,25.9)), c(runif(15,36.4,37.9)), c(runif(15, 20, 2000)))
#'  mask.raster <- raster(xmn = 24.3, xmx = 25.9, ymn = 36.4, ymx = 37.9)
#'  x11();
#'
#'  # Interpolation of data with Shepard" "Modified" and "Neighbours" options
#'  intp_shep <- idwfg(data, mask.raster)
#'  # intp_mod <- idwfg(data, mask.raster, "Modified", R = 2.1)
#'  # intp_neig <- idwfg(data, mask.raster, "Neighbours", N = 12)
#'
#'  # Plot interpolated raster with Shepard (intp_shep) and data points
#'  xy = data[,1:2]
#'  p <- SpatialPoints(xy)
#'  proj4string(p) = CRS(projection(intp_shep$raster))
#'  cexwei = 3 * data[,3]/max(data[,3])
#'  levelplot(intp_shep$raster,
#'            margin = FALSE,
#'            main = "Interpolated field",
#'            scales = list(cex=1.2),
#'            xlab = list("Longitude",cex=1.25),
#'            ylab = list("Latitude",cex=1.25))+
#'            # Add map
#'            latticeExtra::layer({
#'            ext <- as.vector(extent(intp_shep$raster))
#'            boundaries <- map('worldHires', fill=TRUE,
#'                          xlim=ext[1:2], ylim=ext[3:4],
#'                          plot=FALSE)
#'            IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
#'            bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
#'                                    proj4string = CRS(projection(intp_shep$raster)))
#'            sp.polygons(bPols, fill = 'grey80', data = list(bPols=bPols))
#'                                })+
#'            latticeExtra::layer(sp.points(p, pch = 20, col = "blue", cex = cexwei))
#' @export
idwfg <- function(dataframe, rmask, method = "Shephard", p = 2, R = 2, N = 15) {
    print("Interpolation may take some time ...")
    x_centers <- xFromCol(rmask)
    y_centers <- yFromRow(rmask)
    # Create grid
    grd <- expand.grid(x_centers, y_centers)
    int <- phylin::idw(dataframe[, 3], dataframe[, 1:2], grd[, 1:2], method, p, R, N)
    rast = rasterize(grd, field = int$Z, rmask)

    # Leave-one-out validation routine for error
    IDW.out <- numeric(length = length(dataframe[, 3]))
    for (i in 1:length(dataframe[, 3])) {
        int <- phylin::idw(dataframe[-i, 3], dataframe[-i, 1:2], grd[, 1:2], method, p,
            R, N)
        predicted = cbind(grd, int$Z)
        distances = sqrt((predicted[, 1] - dataframe[i, 1])^2 + (predicted[, 2] - dataframe[i,
            2])^2)
        md <- which.min(distances)
        IDW.out[i] <- predicted[md, 3]
    }
    # Calculate error
    rmse = sqrt(mean((IDW.out - dataframe[, 3])^2, na.rm = TRUE))
    # if (rmse>10) warning('rmse error is high, adjust power or number of neighbours')
    return(list("raster" = rast, "RMSE" = rmse))
}

### Normalise raster ###

#' Normalisation of a data object
#'
#' It normalises a data object x to [0,1] using the formula
#' (x-xmin)/(xmax-xmin).
#' @importFrom raster values
#'
#' @param x The data object can be a vector, matrix, dataframe, Shapefile, or
#' RasterLayer object.
#' @param class If missing, the class is numeric, otherwise must be defined.
#' Other options are Shapefile and RasterLayer objects.
#' @return A data object with values in [0,1].
#' @examples
#'
#'
#' library(raster)
#' library(fprmcda)
#' #-- Example 1 --#
#' x <- rnorm(100)
#' FuzzyMember(x)
#'
#' #-- Example 2 --#
#' v1 <- rnorm(10)
#' v2 <- rpois(10,lambda=2)
#' v3 <- rexp(10)
#' x <- data.frame(v1,v2,v3)
#' FuzzyMember(x$v1)
#' apply(x, 2, FuzzyMember)
#'
#' #-- Example 3 --#
#' r <- raster(ncol=5, nrow=5)
#' r <- init(r, rnorm)
#' rFM <- FuzzyMember(r, "raster")
#' par(mfrow=c(2,1))
#' plot(r)
#' plot(rFM)
#'
#' #-- Example 4 --#
#' library(rgdal)
#' shp <- readOGR(system.file("extdata", "grid_polygon", package = "fprmcda"), 'grid_polygon_example3')
#' names(shp)
#'
#' shpFM <- FuzzyMember(shp$depth)
#' range(shp$depth)
#' range(shpFM)
#'
#' @export
FuzzyMember <- function(x, class = F) {
    if (class == "raster") {
        values(x) <- (values(x) - min(values(x), na.rm = T))/(max(values(x), na.rm = T) -
            min(values(x), na.rm = T))
    } else {
        x <- (x - min(x, na.rm = T))/(max(x, na.rm = T) - min(x, na.rm = T))
    }
    return(x)
}

#' Dataframe to RasterLayer conversion.
#'
#' Converts a dataframe with x,y locations and values to a RasterLayer object.
#' @importFrom sp SpatialPolygonsDataFrame coordinates over proj4string
#' @importFrom methods slot as
#' @importFrom raster projection extent raster rasterize res
#' @importFrom spatstat as.ppp dirichlet
#' @importFrom stats median
#' @import deldir
#' @import maptools
#'
#' @aliases csv2raster
#' @param dataframe A dataframe (columns 1,2 should be x,y locations). At least
#' one more column with values is needed.
#' @param value The column of the dataframe with value.
#' @param map.projection Map projection of the points.
#' @return A rasterLayer object.
#' @examples
#'
#' library(fprmcda)
#' library(raster)
#' suppressWarnings(library(maptools))
#' suppressWarnings(library(deldir))
#'
#' df <- read.csv(system.file("extdata", "MyData.csv", package = "fprmcda"), header = TRUE, sep = ",")
#' head(df)
#' dim(df)
#' names(df)
#' # Assign a projection to the csv dataframe
#' map.proj <- CRS("+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0")
#' # Convert an attribute of the csv (e.g., bathymetry) to raster
#' r <- csv2raster(df, df$Bathymetry, map.proj)
#' x11(); plot(r)
#'
#' @export
csv2raster <- function(dataframe, value, map.projection) {
    # warning("First and second columns of the dataframe should be longitude and latitude points")
    # Columns 1 and 2 of the dataframe should hold Lon and Lat coordinates
    names(dataframe)[1] <- "Longitude"
    names(dataframe)[2] <- "Latitude"
    coordinates(dataframe) <- ~Longitude + Latitude
    projection(dataframe) <- map.projection
    th <- as(dirichlet(as.ppp(dataframe)), "SpatialPolygons")
    proj4string(th) <- proj4string(dataframe)
    th.z <- over(th, dataframe)
    th.spdf <- SpatialPolygonsDataFrame(th, th.z)  # it creates the shapefile as polygon
    tt <- sapply(slot(th.spdf, "polygons"), slot, "area")  # It calculates the area of the polygons
    size = sqrt(median(tt))  # It takes the median of polygon areas and calculates the size of the side
    r <- raster(extent(th.spdf))  # creates a raster with the extent of th.spdf
    projection(r) <- proj4string(th.spdf)  # uses the projection of the th.spdf
    # sets the resolution of the raster similar to median side of polygon area of the
    # th.spdf
    res(r) = size
    fr <- rasterize(th.spdf, field = value, r)  # converts th.spdf with Bathymetry attribute to a raster
    return(fr)
}



#' Shapefile to RasterLayer conversion.
#'
#' Converts a shapefile to a RasterLayer object.
#' @importFrom methods slot
#' @importFrom raster extent raster rasterize projection res
#'
#' @param shpfile A shapefile object.
#' @param value An attribute of the shpfile.
#' @param map.projection If missing, it takes the map projection of the
#' shpfile.
#' @return A RasterLayer object.
#' @examples
#'
#'   library(fprmcda)
#'   library(raster)
#'   library(deldir)
#'   library(rgdal)
#'
#' shp <- readOGR(system.file("extdata", "grid_polygon", package = "fprmcda"), 'grid_polygon_example3')
#' projection(shp)
#' names(shp)
#' $ Convert an attribute of shapefile to raster
#' r <- shp2raster(shp, shp$depth)
#' x11(); plot(r)
#' @export
shp2raster <- function(shpfile, value, map.projection = proj4string(shpfile)) {
    tt <- sapply(slot(shpfile, "polygons"), slot, "area")  # It calculates the area of the polygons
    size = sqrt(median(tt))  # It takes the median of polygon areas and calculates the size of the side
    r <- raster(extent(shpfile))  # creates a raster with the extent of shpfile
    projection(r) <- map.projection  # uses the projection of the shpfile
    # sets the resolution of the raster similar to median side of polygon area of the
    res(r) = size
    fr <- rasterize(shpfile, field = value, r)  # converts shpfile with value to a raster
    return(fr)
}
