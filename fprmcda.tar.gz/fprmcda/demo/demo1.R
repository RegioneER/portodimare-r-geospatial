#----------------------------------------------------------------------#
#-------------------------- Run demo-1 --------------------------------#
#----------------------------------------------------------------------#
# For more details of demo1, see the vignette of the package
# path <- system.file("doc", "fprmcdaTutorial.pdf", package = "fprmcda")
# system(paste0('open "', path, '"'))
# Load libraries
library(rgdal)        # load shapefiles
library(raster)       # handle raster objects
library(RColorBrewer) # define colorbars for raster
library(rasterVis)    # plot raster objects
library(maps)         # display of maps
library(mapdata)      # load map databases
library(maptools)     # mapping tool
library(latticeExtra) # graphical utilities
library(FuzzyAHP)     # Analytic Hierarchy Process
library(spatstat)     # spatial statistics tool
library(phylin)       # perform IDW interpolation
#------------- Load parameters, data --------------#
# Define grades for bathymetry
bath_cuts <- c( -Inf, 0, 50, 100, 150, 200, 500 )
bath_grad <- c(   NA, 1,  2,   3,  4,    5,   0 )
# Define grades for distance from coast
coastdist_cuts <- c( -Inf, 0, 1.5, 3, 6)
coastdist_grad <- c(   NA, 4,   3, 2, 1)
# Define grades for sea surface chrollophyl
chl_cuts <- c( -Inf, 0, 1, 2, 2.5, 3)
chl_grad <- c(    0, 1, 2, 3,   4, 5)

# Pairwise comparison matrix for performing Analytic Hierarchy Process (AHP)
ComparisonMatrixValues<-c(  1,   2, 3,
                          1/2,   1, 5,
                          1/3, 1/5, 1)
ComparisonMatrixValues = matrix(ComparisonMatrixValues,
                                nrow = sqrt(length(ComparisonMatrixValues)),
                                ncol = sqrt(length(ComparisonMatrixValues)),
                                byrow = TRUE)
ComparisonMatrixValues

# Load raster data
raster_data <- brick(system.file("external", "FishData.grd", package="fprmcda"))

# Explore Data
names(raster_data)
nlayers(raster_data)

# Load fishing gear data
filename <- system.file("external", "Fishing_Ports.csv", package = "fprmcda")
fg <- read.csv(filename, sep= ",") # dataframe columns should be lon, lat, fishing gear (gtl)
# --------------------------------------------------------#
#------------ Multi-Criteria Decision Analysis -----------#
# --------------------------------------------------------#
# Plot bathymetry
x11()
levelplot(raster_data$Bathymetry,
          margin = F,
          main = "Bathymetry (m)",
          par.settings = BuRdTheme,
          scales = list(cex = 1.2),
          xlab = list("Longitude",cex = 1.2),
          ylab = list("Latitude",cex = 1.2))+
  # Add map on the leveplot
  latticeExtra::layer({
  ext <- as.vector(extent(raster_data$Bathymetry))
  boundaries <- map('worldHires', fill = TRUE,
                      xlim = ext[1:2], ylim = ext[3:4],
                      plot = FALSE)
  IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
                               proj4string = CRS(projection(raster_data$Bathymetry)))
  sp.polygons(bPols, fill = 'grey80', data = list(bPols = bPols))
  })

# Define the graded raster and update its values following cuts and grades
graded_raster = raster_data
values(graded_raster$Bathymetry)  <- fgrade(values(raster_data$Bathymetry), bath_cuts, bath_grad)
values(graded_raster$CoastDist)   <- fgrade(values(raster_data$CoastDist)/1852, coastdist_cuts, coastdist_grad)
values(graded_raster$Chlorophyll) <- fgrade(values(raster_data$Chlorophyll), chl_cuts, chl_grad)


# Plot graded bathymetry
x11()
levelplot(ratify(graded_raster$Bathymetry),
          cuts = max(values(graded_raster$Bathymetry), na.rm=TRUE),
          margin = F,
          col.regions = brewer.pal(n = 9, "Blues"),
          main = "Bathymetry (graded)",
          att = "ID",
          scales = list(cex = 1.2),
          xlab = list("Longitude",cex = 1.2),
          ylab = list("Latitude",cex = 1.2))+
  # Add map on the leveplot
  latticeExtra::layer({
  ext <- as.vector(extent(graded_raster$Bathymetry))
  boundaries <- map('worldHires', fill = TRUE,
                      xlim = ext[1:2], ylim = ext[3:4],
                      plot = FALSE)
  IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
                                 proj4string = CRS(projection(graded_raster$Bathymetry)))
  sp.polygons(bPols, fill = 'grey80', data = list(bPols = bPols))
  })

# Apply AHP to pairwise matrix defined to calculate weights, consistency ratio, e.t.c.
ahp_out = ahp_optim(ComparisonMatrixValues)

# Apply of Weighted Linear Combination to calculate Sc = Sum(weights * graded_data)
Sc = sum(ahp_out$weights * graded_raster)

# Normalise Sc
Sc <- FuzzyMember(Sc, "raster")

# Plot the Fish Suitability Index (Sc)
x11()
levelplot(Sc,
          margin = F,
          main = "Fish Suitability Index (Sc)",
          scales = list(cex=1.2),
          par.settings= BuRdTheme,
          xlab = list("Longitude",cex = 1.2),
          ylab = list("Latitude",cex = 1.2))+
  # Add map on the leveplot
  latticeExtra::layer({
  ext <- as.vector(extent(Sc))
  boundaries <- map('worldHires', fill=TRUE,
                      xlim = ext[1:2], ylim=ext[3:4],
                      plot = FALSE)
  IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
                                 proj4string = CRS(projection(Sc)))
  sp.polygons(bPols, fill = 'grey80', data = list(bPols = bPols))
  })

# Apply IDW interpolation to fishing gear data using bathymetry as mask raster
fg_intp <- idwfg(fg, raster_data$Bathymetry)

# Spatialize fishing Lon, Lat data points
xy = fg[,1:2]
p <- SpatialPoints(xy)
proj4string(p) = CRS(projection(fg_intp$raster))
cexwei = 3*fg[,3] / max(fg[,3])

# Normalise interpolated fishing gear
fg_intp$raster = FuzzyMember(fg_intp$raster, "raster")

# Plot interpolated fishing gear
x11()
levelplot(fg_intp$raster,
          margin = F,
          main = "Fishing Gear (interpolated)",
          scales = list(cex = 1.2),
          par.settings = BuRdTheme,
          xlab = list("Longitude",cex = 1.25),
          ylab = list("Latitude",cex = 1.25))+
  # Add map on the leveplot
  latticeExtra::layer({
  ext <- as.vector(extent(fg_intp$raster))
  boundaries <- map('worldHires', fill = TRUE,
                      xlim = ext[1:2], ylim = ext[3:4],
                      plot = FALSE)
  IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
                              proj4string = CRS(projection(fg_intp$raster)))
  sp.polygons(bPols, fill = 'grey80', data = list(bPols = bPols))
  })+
  latticeExtra::layer(sp.points(p, pch = 20, col = "blue", cex = cexwei))

# Calculate Fishing Pressure: FPc = Sc * fg_intp$raster
FPc = Sc * fg_intp$raster
# Normalise FPc
FPc <- FuzzyMember(FPc, "raster")

# Plot FPc
x11()
levelplot(FPc,
          margin = F,
          main = "Fishing pressure (FPc)",
          scales = list(cex = 1.2),
          par.settings = BuRdTheme,
          xlab = list("Longitude",cex = 1.2),
          ylab = list("Latitude",cex = 1.2))+
  # Add map on leveplot
  latticeExtra::layer({
  ext <- as.vector(extent(FPc))
  boundaries <- map('worldHires', fill = TRUE,
                      xlim = ext[1:2], ylim = ext[3:4],
                      plot = FALSE)
  IDs <- sapply(strsplit(boundaries$names, ":"), function(x) x[1])
  bPols <- map2SpatialPolygons(boundaries, IDs = IDs,
                                 proj4string = CRS(projection(FPc)))
  sp.polygons(bPols, fill = 'grey80', data = list(bPols = bPols))
  })
