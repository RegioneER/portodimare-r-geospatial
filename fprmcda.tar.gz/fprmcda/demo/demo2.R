#--------------------------------------------------#
#--------------------------------------------------#
#------------------ Run demo-2 --------------------#
#--------------------------------------------------#
# Load libraries
library(rgdal)        # load shapefiles
library(raster)       # handle raster objects
library(RColorBrewer) # define colorbars for raster
library(rasterVis)    # plot raster objects
library(maps)         # display of maps
library(mapdata)      # load map databases
library(maptools)     # mapping tool
library(latticeExtra) # graphical utilities
library(FuzzyAHP)     # Analytic Hierarchy Process
library(spatstat)     # spatial statistics tool
library(phylin)       # perform IDW interpolation
library(tmap)         # provide plots with tmap
#library(tmaptools)    # auxiliary for tmap
#------------- Load parameters, data --------------#
# Define grades for bathymetry
bath_cuts <- c( -Inf, 0, 50, 100, 200, 500 )
bath_grad <- c(   NA, 4,  3,   2,   1,   0 )
# Define grades for distance from coast
coastdist_cuts <- c( -Inf, 0, 1.5, 3, 6  )
coastdist_grad <- c(   NA, 4,   3, 2, 1 )
# Define grades for sea surface Chrollophyl
ssc_cuts <- c( -Inf, 0.1, 0.23, 0.46, 0.793 )
ssc_grad <- c(    0,   1,    2,    3,     4 )
# Define grades for legislation
leg_cuts <- c( -Inf, 0, 3, 6, 11 )
leg_grad <- c(   NA, 4, 3, 2,  0 )
# Define grades for marine traffic activity
mtraf_cuts <- c( -Inf, 0, 1, 2, 3 )
mtraf_grad <- c(  NA,  0, 1, 2, 3 )
# Define grades for bottom trawl fleet effort
trfleet_cuts <- c( -Inf, 0, 0.2, 0.4, 0.8 )
trfleet_grad <- c(   NA, 1,   2,   3,   4 )
# Define scores for purse seine fleet effort
psfleet_cuts <- c( -Inf, 0, 0.2, 0.4, 0.8 )
psfleet_grad <- c(   NA, 1,   2,   3,   4 )

# Pairwise matrix of components for performing Analytic Hiearchy Process
ComparisonMatrixValues <- c(  1,  2,    4,   5,   4, 4,   3,
                            1/2,  1,    6,   4,   4, 5,   5,
                            1/4, 1/6,   1,   1,   2, 1, 1/2,
                            1/5, 1/4,   1,   1,   3, 3, 1/2,
                            1/4, 1/4, 1/2, 1/3,   1, 2, 1/3,
                            1/4, 1/5,   1, 1/3, 1/2, 1,   1,
                            1/3, 1/5,   2,   2,   3, 1,   1 )
ComparisonMatrixValues = matrix(ComparisonMatrixValues,
                                nrow = sqrt(length(ComparisonMatrixValues)),
                                ncol = sqrt(length(ComparisonMatrixValues)),
                                byrow = TRUE)
ComparisonMatrixValues
# --------------------------------------------------------------
# Load components affecting Small Scale Fisheries (SSF)
comp_ssf <- brick(system.file("external", "comp_SSF.grd", package = "fprmcda"))

# Load fishing gear data for interpolation
filename <- system.file("external", "Fishing_Gear.csv", package = "fprmcda")
fg <- read.csv(filename, sep = ",") # dataframe columns should be lon, lat, gtl

# Load map of case study
fmap <- system.file("external", package = "fprmcda")
map_domain <- readOGR(fmap, "CoastLine_Polygon")

# Extension of model domain
ext <- as.vector(extent(comp_ssf))
# --------------------------------------------------------#
#------------ Multi-Criteria Decision Analysis -----------#
# --------------------------------------------------------#
# Plot Bathymetry
x11()
tmap_mode("plot")
tm_shape(comp_ssf) + tm_raster("Bathymetry", title = "", breaks = c(0, 25, 50 ,100, 200, 400, 600, 800, 1000, 1200)) +
  tm_shape(map_domain) + tm_polygons(xlim = c(round(ext[1],1), round(ext[2],1)), ylim = c(round(ext[3],1), round(ext[4],1))) +
  tm_grid(labels.inside.frame = FALSE, n.x = 5, n.y = 4, col = "black", labels.size = 1)+
  tm_layout(panel.labels = "Bathymetry (m)", outer.margins = c(.1,.1,.1,.1)) +
  tm_legend(position = c("right", "top"), bg.color = "grey75", frame=TRUE)

# Initialize the graded raster and update its values following cuts and grades
graded_comp_ssf = comp_ssf
values(graded_comp_ssf$Bathymetry)              <- fgrade(values(comp_ssf$Bathymetry), bath_cuts, bath_grad)
values(graded_comp_ssf$CoastDist)               <- fgrade(values(comp_ssf$CoastDist)/1852, coastdist_cuts, coastdist_grad)
values(graded_comp_ssf$Legislation)             <- fgrade(values(comp_ssf$Legislation), leg_cuts, leg_grad)
values(graded_comp_ssf$Marine_Traffic_Activity) <- fgrade(values(comp_ssf$Marine_Traffic_Activity), mtraf_cuts, mtraf_grad)
values(graded_comp_ssf$Bottom_Fleet)            <- fgrade(values(comp_ssf$Bottom_Fleet), trfleet_cuts, trfleet_grad)
values(graded_comp_ssf$Purse_Seine_Fleet)       <- fgrade(values(comp_ssf$Purse_Seine_Fleet), psfleet_cuts, psfleet_grad)
values(graded_comp_ssf$Chlorophyl)              <- fgrade(values(comp_ssf$Chlorophyl), ssc_cuts, ssc_grad)

# Plot the graded raster of Bathymetry
x11()
tmap_mode("plot") #palette = "YIOrBr"
tm_shape(graded_comp_ssf) + tm_raster("Bathymetry", style = "cat", palette = brewer.pal(n = 5, "Blues"), title = "", legend.reverse = TRUE) +
  tm_shape(map_domain) + tm_polygons(xlim = c(round(ext[1],1), round(ext[2],1)), ylim = c(round(ext[3],1), round(ext[4],1))) +
  tm_grid(labels.inside.frame = FALSE, n.x = 5, n.y = 4, col = "black", labels.size = 1)+
  tm_layout(panel.labels = "Graded Bathymetry", outer.margins = c(.1,.1,.1,.1)) +
  tm_legend(position = c("right", "top"), bg.color="grey75", frame = TRUE)

# Apply AHP to pairwise matrix defined to calculate weights, consistency ratio, e.t.c.
ahp_out = ahp_optim(ComparisonMatrixValues)

# Apply of Weighted Linear Combination to calculate Sc = Sum(weights * graded_data)
Sc = sum(ahp_out$weights * graded_comp_ssf[[1:7]])

# Normalise Sc
Sc <- FuzzyMember(Sc, "raster")

# Plot the Fish Suitability Index (Sc)
x11()
tmap_mode("plot")
tm_shape(Sc) + tm_raster("layer", style = "cont", palette = "Blues", title = "", legend.reverse = TRUE) +
  tm_shape(map_domain) + tm_polygons(xlim = c(round(ext[1],1), round(ext[2],1)), ylim = c(round(ext[3],1), round(ext[4],1))) +
  tm_grid(labels.inside.frame = FALSE, n.x = 5, n.y = 4, col = "black", labels.size = 1)+
  tm_layout(panel.labels = "Fish Suitability Index (Sc)", outer.margins = c(.1,.1,.1,.1)) +
  tm_legend(position = c("right", "top"), bg.color = "grey75", frame = TRUE)

# Apply IDW interpolation to fishing gear (fg) data; use graded_comp_ssf$Bathymetry as mask.raster
fg_intp <- idwfg(fg, graded_comp_ssf$Bathymetry)

# Spatialize fishing gear data points (Lon, Lat) and convert to SpatialPointsDataFrame
xy = fg[,1:2]
p <- SpatialPoints(xy)
proj4string(p) = CRS(projection(fg_intp$raster))
df <- data.frame(attr1 = c("f1","f2","f3","f4","f5","f6","f7","f8","f9","f10","f11"), gear = fg[,3])
fgear <- SpatialPointsDataFrame(p, df)

# Plot interpolated fishing gear
x11()
tmap_mode("plot")
tm_shape(fg_intp$raster) + tm_raster("layer", style = "cont", title = "Interpolation", legend.reverse = TRUE) +
  tm_shape(map_domain) + tm_polygons(xlim = c(round(ext[1],1), round(ext[2],1)), ylim = c(round(ext[3],1), round(ext[4],1))) +
  tm_shape(fgear) + tm_bubbles(size = "gear", col = "blue",  title.size = "Data") +
  tm_grid(labels.inside.frame = FALSE, n.x = 5, n.y = 4, col = "black", labels.size = 1)+
  tm_layout(panel.labels = "Interpolated Fishing Gear", outer.margins = c(.1,.1,.1,.1)) +
  tm_legend(position = c("right", "top"), bg.color = "grey95", frame = TRUE)

# Normalise interpolated fishing gear
fg_intp$Ac = FuzzyMember(fg_intp$raster, "raster")

# Calculate Fishing Pressure: FPc = Sc * fg_intp$raster * No_Take_Zones
FPc = Sc * fg_intp$raster * graded_comp_ssf[[8]]

# Normalise FPc
FPc <- FuzzyMember(FPc, "raster")

# Plot FPc
x11()
tmap_mode("plot")
tm_shape(FPc) + tm_raster("layer", palette = "Blues", title = "") +
  tm_shape(map_domain) + tm_polygons(xlim = c(round(ext[1],1), round(ext[2],1)), ylim = c(round(ext[3],1), round(ext[4],1))) +
  tm_grid(labels.inside.frame = FALSE, n.x = 5, n.y = 4, col = "black", labels.size = 1)+
  tm_layout(panel.labels = "Fishing Pressure (FPc)", outer.margins = c(.1,.1,.1,.1)) +
  tm_legend(position = c("right", "top"), bg.color="grey75", frame = TRUE)
